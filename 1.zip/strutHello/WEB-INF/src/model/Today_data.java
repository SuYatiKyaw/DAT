package model;

public class Today_data {
	
	int customer_id;
	String customer_name;
	int order_price,order_quantity,order_amount;
	

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public int getOrder_price() {
		return order_price;
	}

	public void setOrder_price(int order_price) {
		this.order_price = order_price;
	}

	public int getOrder_quantity() {
		return order_quantity;
	}

	public void setOrder_quantity(int order_quantity) {
		this.order_quantity = order_quantity;
	}

	public int getOrder_amount() {
		return order_amount;
	}

	public void setOrder_amount(int order_amount) {
		this.order_amount = order_amount;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public Today_data(int customer_id, String customer_name, int order_price,
			int order_quantity, int order_amount) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.order_price = order_price;
		this.order_quantity = order_quantity;
		this.order_amount = order_amount;
	}
	
	

	
	
	

}
