
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import model.Customer_Order;

import com.opensymphony.xwork2.ActionSupport;

import dbo.DBOperation;

public class SearchAction extends ActionSupport {

	private Date today_date;
	private Date from_date, to_date;

	ArrayList<Customer_Order> s_list;
	ArrayList<Customer_Order> search_list;
	HttpServletRequest request = ServletActionContext.getRequest();
	HttpSession session = request.getSession();

	public ArrayList<Customer_Order> getS_list() {
		return s_list;
	}

	public void setS_list(ArrayList<Customer_Order> s_list) {
		this.s_list = s_list;
	}

    

	public Date getToday_date() {
		return today_date;
	}

	public void setToday_date(Date today_date) {
		this.today_date = today_date;
	}

	public Date getFrom_date() {
		return from_date;
	}

	public void setFrom_date(Date from_date) {
		this.from_date = from_date;
	}

	public Date getTo_date() {
		return to_date;
	}

	public void setTo_date(Date to_date) {
		this.to_date = to_date;
	}
	
	@Override
	public void validate() {
	
		if (from_date.after(today_date) || from_date.equals(today_date)) {
			addFieldError("from_date", "From Order date must be less than Today.");
	}
	
	if (to_date.equals(today_date) || to_date.before(from_date)) {
		addFieldError("to_date", "To Order date must be between Today and From Order Date.");
     }
	

	}

	public String execute() throws Exception {
		
		if (to_date.before(from_date)) {
			System.out.println("To Order date must be between Today and From Order Date");
	}
		
		
		
		
				
		boolean result=true;                                    ;

		DBOperation dbo = new DBOperation();
		ArrayList<Customer_Order> s_list = dbo.search(today_date, from_date, to_date);
		
		
		System.out.println(s_list.isEmpty()+"is Empty case");
		
		if(s_list.isEmpty()){
			result=false;
		}else{
			for (Customer_Order cust : s_list) {
				

				
				System.out.println(cust.getCustomer_id() + " "
						+ cust.getCustomer_name() + " "
						+ cust.getToday_order_amount() + " "
						+ cust.getToday_order_amount() + " "
						+ cust.getPrevious_avg_order_amount());
				session.setAttribute("search_list", s_list);
				ArrayList<Customer_Order> search_list = (ArrayList<Customer_Order>) session
						.getAttribute("search_list");

	}
		}


		
		System.out.println(result+"result");
		if(result==true){
			return "success";
		}
		else{
			return "error";
		}
		
		

	}

}
