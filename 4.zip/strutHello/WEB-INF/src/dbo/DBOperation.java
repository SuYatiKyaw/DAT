package dbo;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;

import java.util.Date;

import model.Customer_Order;
import model.Search_data;
import model.Today_data;


import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class DBOperation {

	public ArrayList<Customer_Order> search(Date today, Date from_date,Date to_date) throws SQLException, ClassNotFoundException {
	
		ArrayList<Customer_Order> customer = new ArrayList<Customer_Order>();
		ArrayList<Integer> today_data = new ArrayList<Integer>();
		ArrayList<Integer> search_data = new ArrayList<Integer>();
			
		ArrayList<Today_data> today_datas = new ArrayList<Today_data>();
		ArrayList<Search_data> search_datas = new ArrayList<Search_data>();
		
		
		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		String input_today_date = formatter1.format(today);
		
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String input_to_date = formatter.format(from_date);
		String input_from_date = formatter.format(to_date);
		
	

		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/dat";
		Statement st,st1,st2,st3,st4;
		ResultSet rs;
		ResultSet rs1;
		ResultSet rs2,rs3,rs4;
		Class.forName(driver);
		Connection con = (Connection) DriverManager.getConnection(url, "root","root");

		String sql = "SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date = '"+input_today_date+"'";
		st = (Statement) con.createStatement();
		rs = st.executeQuery(sql);	
		while (rs.next()) {
			today_data.add(rs.getInt(1));
		}

		for(int t_data:today_data){
			String sql1 = "SELECT c.customer_id,c.customer_name,order_price,order_quantity,AVG(order_quantity*order_price) AS order_amount FROM customer_order,customer as c inner join customer on c.customer_id=c.customer_id WHERE c.customer_id='"+t_data+"'";	
			st1 = (Statement) con.createStatement();
			rs1 = st1.executeQuery(sql1);
			 if(rs1.next()){		
					
					Today_data t_order=new Today_data(rs1.getInt(1),rs1.getString(2),rs1.getInt(3),rs1.getInt(4),rs1.getInt(5));
				
					today_datas.add(t_order);	
					
					System.out.println("today_datas"+today_datas);
			 }			
		}
		
		String sql2 = "SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date = '"+input_from_date+"' AND to_order_date='"+input_to_date+"'";
		st2 = (Statement) con.createStatement();
		rs2 = st.executeQuery(sql);	
		while (rs2.next()) {
			search_data.add(rs2.getInt(1));
		}
		
		
		for(int s_data:search_data){
			String sql3 = "SELECT c.customer_id,c.customer_name,order_price,order_quantity,AVG(order_quantity*order_price) AS order_amount FROM customer_order,customer as c inner join customer on c.customer_id=c.customer_id WHERE c.customer_id='"+s_data+"'";	
			st3 = (Statement) con.createStatement();
			rs3 = st3.executeQuery(sql3);
			 if(rs3.next()){		
					Search_data s_order=new Search_data(rs3.getInt(1),rs3.getString(2),rs3.getInt(3),rs3.getInt(4),rs3.getInt(5));		
					
					search_datas.add(s_order);
					System.out.println("search_datas"+search_datas);
			 }			
		}
		
		 for (Today_data t_d : today_datas) { 
			 for(Search_data s_d:search_datas){
				if(t_d.getOrder_amount()>s_d.getOrder_amount()*0.75){	
					System.out.println(t_d.getCustomer_id());
					Customer_Order co=new Customer_Order(t_d.getCustomer_id(),t_d.getCustomer_name(),t_d.getOrder_amount(),s_d.getOrder_amount());					
					customer.add(co);	
				 }				 
			 }			 
		 }
		 System.out.println(customer);
		 
	

		return customer;
	}
}
