drop table `dat`.`product`;
drop table `dat`.`customer`;
drop table `dat`.`customer_order`;


CREATE TABLE `dat`.`product` (
  `product_id` INT NOT NULL AUTO_INCREMENT,
  `product_name` VARCHAR(30) NULL,
  `company_name` VARCHAR(45) NULL,
  PRIMARY KEY (`product_id`)
);


CREATE TABLE `dat`.`customer` (
  `customer_id` INT NOT NULL AUTO_INCREMENT,
  `customer_name` VARCHAR(30) NULL,
   PRIMARY KEY (`customer_id`)
);


CREATE TABLE `dat`.`customer_order`(
  `order_id` INT NOT NULL AUTO_INCREMENT,
  `order_type` VARCHAR(30) NULL,
  `day_order_type` VARCHAR(14) NULL,
  `from_order_date` DATE NULL,
  `to_order_date` DATE NULL,
  `order_price` INT(15) NULL,
  `order_quantity` INT(8) NULL,
  `status` VARCHAR(20) NULL,
  `order_status` VARCHAR(20) NULL,
  `customer_id` INT,
  `product_id` INT,
  PRIMARY KEY (`order_id`),
  FOREIGN KEY (`customer_id`) REFERENCES `dat`.CUSTOMER(`customer_id`) ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (`product_id`)  REFERENCES `dat`.PRODUCT(`product_id`) ON UPDATE CASCADE ON DELETE CASCADE
);


INSERT INTO product (product_name,company_name)VALUES ('product1', 'company1');
INSERT INTO product (product_name,company_name)VALUES ('product2', 'company2');
INSERT INTO product (product_name,company_name)VALUES ('product3', 'company3');
INSERT INTO product (product_name,company_name)VALUES ('product4', 'company4');
INSERT INTO product (product_name,company_name)VALUES ('product5', 'company5');
INSERT INTO product (product_name,company_name)VALUES ('product6', 'company6');
INSERT INTO product (product_name,company_name)VALUES ('product7', 'company7');
INSERT INTO product (product_name,company_name)VALUES ('product8', 'company8');
INSERT INTO product (product_name,company_name)VALUES ('product9', 'company9');
INSERT INTO product (product_name,company_name)VALUES ('product10', 'company10');

INSERT INTO customer (customer_name)VALUES ('customer1');
INSERT INTO customer (customer_name)VALUES ('customer2');
INSERT INTO customer (customer_name)VALUES ('customer3');
INSERT INTO customer (customer_name)VALUES ('customer4');
INSERT INTO customer (customer_name)VALUES ('customer5');
INSERT INTO customer (customer_name)VALUES ('customer6');
INSERT INTO customer (customer_name)VALUES ('customer7');
INSERT INTO customer (customer_name)VALUES ('customer8');
INSERT INTO customer (customer_name)VALUES ('customer9');
INSERT INTO customer (customer_name)VALUES ('customer10');


select *from customer;


select * from customer_order;


INSERT INTO customer_order
(order_type,day_order_type,from_order_date,to_order_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('LO','DO','2019-12-04','2019-12-04',5000,5,'2','1',1,1);

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,to_order_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('MO','DO','2019-12-10','2019-12-04',5000,6,'1','1',2,1);

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,to_order_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('LO','GO','2019-12-03','2019-09-04',5000,7,'1','1',1,1);

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,to_order_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('LO','DO','2019-09-07','2019-09-07',5000,8,'1','1',3,1);


INSERT INTO customer_order
(order_type,day_order_type,from_order_date,to_order_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('MO','DO','2019-09-08','2019-09-08',5000,7,'1','2',3,1);

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,to_order_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES (' LO','DO','2019-09-08','2019-09-08',50000000,4,'1','2',3,1);



INSERT INTO customer_order
(order_type,day_order_type,from_order_date,to_order_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES (' LO','DO','08/08/2019','08/08/2019',50000000,4,'1','2',3,1);





get today date,,
SELECT customer_id,order_price,order_quantity,(order_quantity*order_price)/order_quantity AS order_amount FROM customer_order WHERE from_order_date = '2019-12-04'AND  customer_id='1';



SELECT customer_id,order_price,order_quantity FROM customer_order WHERE from_order_date = '2019-12-03' AND to_order_date = '2019-09-04' AND  customer_id='1';

SELECT customer_id,order_price,order_quantity,(order_quantity*order_price)/order_quantity AS order_amount FROM customer_order WHERE from_order_date = '2019-12-03' AND to_order_date = '2019-09-04' AND  customer_id='2'

SELECT customer_id,order_price,order_quantity,(order_quantity*order_price)/order_quantity AS order_amount FROM customer_order WHERE from_order_date = '2019-12-03' AND to_order_date = '2019-09-04' AND  customer_id='1'


SELECT customer_id,order_price,order_quantity,(order_quantity*order_price)/order_quantity AS order_amount FROM customer_order WHERE customer_id='1'




SELECT c.customer_id,c.customer_name,order_price,order_quantity,(order_quantity*order_price)/order_quantity AS order_amount FROM customer_order,customer as c
inner join customer on c.customer_id=c.customer_id WHERE c.customer_id='1';


SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date = '2019-12-03' AND to_order_date='2019-09-04';


SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date = '2019-12-04';


SELECT c.customer_id,c.customer_name,order_price,order_quantity,AVG(order_quantity*order_price) AS order_amount 
FROM customer_order,customer as c inner join customer on c.customer_id=c.customer_id 
WHERE  c.customer_id=
(SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date = '2019-12-03' AND to_order_date='2019-09-04');

SELECT c.customer_id,c.customer_name,order_price,order_quantity,AVG(order_quantity*order_price) AS order_amount 
FROM customer_order,customer as c inner join customer on c.customer_id=c.customer_id 
WHERE c.customer_id=(SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date = '2019-12-04');


select * from customer_order;

delete table customer_order;


SELECT customer_id FROM customer_order WHERE from_order_date = '2019-12-03' AND to_order_date='2019-09-04';
SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date = '2019-12-04';

SELECT c.customer_id,c.customer_name,order_price,order_quantity,AVG(order_quantity*order_price) AS order_amount FROM customer_order,customer as c inner join customer on c.customer_id=c.customer_id WHERE c.customer_id='1';


SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date = '2019-12-03' AND to_order_date='2019-09-04' AND status='1';


SELECT DISTINCT	(customer_id) FROM customer_order WHERE from_order_date = '2019-12-03' AND to_order_date='2019-09-04' AND status='1';


SELECT c.customer_id,c.customer_name,order_price,order_quantity,AVG(order_quantity*order_price) AS order_amount FROM customer_order,customer as c inner join customer on c.customer_id=c.customer_id WHERE c.customer_id='1';

