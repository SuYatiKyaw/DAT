package dbo;


import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.mysql.jdbc.Connection;

import model.Customer_Order;
import model.Search_data;
import model.Today_data;



public class DBOperation {
	public ArrayList<Customer_Order> search(Date today, Date from_date,
			Date to_date) throws SQLException, ClassNotFoundException {
		ArrayList<Customer_Order> customer = new ArrayList<Customer_Order>();
		ArrayList<Integer> today_data = new ArrayList<Integer>();
		ArrayList<Integer> search_data = new ArrayList<Integer>();
		ArrayList<Today_data> today_datas = new ArrayList<Today_data>();
		ArrayList<Search_data> search_datas = new ArrayList<Search_data>();
		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		String input_today_date = formatter1.format(today);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String input_from_date = formatter.format(from_date);

		SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd");
		String input_to_date = formatter2.format(to_date);

		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/dat";
		Statement st, st1, st2, st3;
		ResultSet rs;
		ResultSet rs1;
		ResultSet rs2, rs3;
		Class.forName(driver);
		Connection con = (Connection) DriverManager.getConnection(url, "root",
				"root");

		String sql = "SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date = '"
				+ input_today_date + "'";

		st = (Statement) con.createStatement();
		rs = st.executeQuery(sql);
		while (rs.next()) {
			today_data.add(rs.getInt(1));
		}

		for (int t_data : today_data) {
			String sql1 = "SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount,count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND order_status='1' AND customer.customer_id='"
					+ t_data
					+ "' AND from_order_date = '"
					+ input_today_date
					+ "'";
			System.out.println("sql1"+sql1);
			
			st1 = (Statement) con.createStatement();
			rs1 = st1.executeQuery(sql1);
			if (rs1.next()) {

				Today_data t_order = new Today_data(rs1.getInt(1),
						rs1.getString(2), rs1.getInt(3), rs1.getInt(4),
						rs1.getInt(5),rs1.getInt(6));

				today_datas.add(t_order);
			}
		}

		String sql2 = "SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date <= '"
				+ input_from_date
				+ "' AND from_order_date >='"
				+ input_to_date
				+ "'";
		
		

		st2 = (Statement) con.createStatement();
		rs2 = st.executeQuery(sql2);
		while (rs2.next()) {
			search_data.add(rs2.getInt(1));
		}

		for (int s_data : search_data) {
			String sql3 = "SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,SUM(order_quantity*order_price) AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND order_status='1' AND customer.customer_id='"
					+ s_data
					+ "'AND from_order_date <= '"
					+ input_from_date
					+ "' AND from_order_date>='" + input_to_date + "'";
			System.out.println("sql3"+sql3);

			st3 = con.createStatement();
			rs3 = st3.executeQuery(sql3);
			if (rs3.next()) {
				Search_data s_order = new Search_data(rs3.getInt(1),
						rs3.getString(2), rs3.getInt(3), rs3.getInt(4),
						rs3.getInt(5),rs3.getInt(6));
				search_datas.add(s_order);
			}
		}
		for (Today_data t_d : today_datas) {
			for (Search_data s_d : search_datas) {
				if(s_d.getDay_count()!=0){
				if (t_d.getOrder_amount() >= (s_d.getOrder_amount()/s_d.getDay_count())*5
						&& t_d.getCustomer_id() == s_d.getCustomer_id()) {
					
					System.out.println(s_d.getOrder_amount());
					System.out.println(s_d.getDay_count());
					System.out.println(s_d.getOrder_amount()/s_d.getDay_count());
					
					int search_order_amount=(s_d.getOrder_amount()/s_d.getDay_count());
					
					Customer_Order co = new Customer_Order(
							t_d.getCustomer_id(), t_d.getCustomer_name(),
							t_d.getOrder_amount(), search_order_amount);
					customer.add(co);
					System.out.println(customer);
				}
				
			}
			}
		}
		return customer;
	}
}
