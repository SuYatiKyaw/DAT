package model;

public class Customer_Order {
	private int customer_id;
	private String customer_name;
	private int today_order_amount;
	private int previous_avg_order_amount;

	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public int getToday_order_amount() {
		return today_order_amount;
	}

	public void setToday_order_amount(int today_order_amount) {
		this.today_order_amount = today_order_amount;
	}

	public int getPrevious_avg_order_amount() {
		return previous_avg_order_amount;
	}

	public void setPrevious_avg_order_amount(int previous_avg_order_amount) {
		this.previous_avg_order_amount = previous_avg_order_amount;
	}

	public Customer_Order(int customer_id, String customer_name,
			int today_order_amount, int previous_avg_order_amount) {
		super();
		this.customer_id = customer_id;
		this.customer_name = customer_name;
		this.today_order_amount = today_order_amount;
		this.previous_avg_order_amount = previous_avg_order_amount;
	}

	public Customer_Order() {
		super();
	}

}
