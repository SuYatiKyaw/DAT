drop table `dat`.`product`;
drop table `dat`.`customer`;
drop table `dat`.`customer_order`;


CREATE TABLE `dat`.`product` (
  `product_id` INT NOT NULL AUTO_INCREMENT,
  `product_name` VARCHAR(30) NULL,
  `company_name` VARCHAR(45) NULL,
  PRIMARY KEY (`product_id`)
);


CREATE TABLE `dat`.`customer` (
  `customer_id` INT NOT NULL AUTO_INCREMENT,
  `customer_name` VARCHAR(30) NULL,
   PRIMARY KEY (`customer_id`)
);


CREATE TABLE `dat`.`customer_order`(
  `order_id` INT NOT NULL AUTO_INCREMENT,
  `order_type` VARCHAR(30) NULL,
  `day_order_type` VARCHAR(14) NULL,
  `from_order_date` DATE NULL,
  `expire_date` DATE NULL,
  `order_price` INT(50) NULL,
  `order_quantity` INT(8) NULL,
  `status` VARCHAR(20) NULL,
  `order_status` VARCHAR(20) NULL,
  `customer_id` INT,
  `product_id` INT,
  PRIMARY KEY (`order_id`),
  FOREIGN KEY (`customer_id`) REFERENCES `dat`.CUSTOMER(`customer_id`) ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (`product_id`)  REFERENCES `dat`.PRODUCT(`product_id`) ON UPDATE CASCADE ON DELETE CASCADE
);


INSERT INTO product (product_name,company_name)VALUES ('product1', 'company1');
INSERT INTO product (product_name,company_name)VALUES ('product2', 'company2');
INSERT INTO product (product_name,company_name)VALUES ('product3', 'company3');
INSERT INTO product (product_name,company_name)VALUES ('product4', 'company4');
INSERT INTO product (product_name,company_name)VALUES ('product5', 'company5');
INSERT INTO product (product_name,company_name)VALUES ('product6', 'company6');
INSERT INTO product (product_name,company_name)VALUES ('product7', 'company7');
INSERT INTO product (product_name,company_name)VALUES ('product8', 'company8');
INSERT INTO product (product_name,company_name)VALUES ('product9', 'company9');
INSERT INTO product (product_name,company_name)VALUES ('product10', 'company10');

INSERT INTO customer (customer_name)VALUES ('customer1');
INSERT INTO customer (customer_name)VALUES ('customer2');
INSERT INTO customer (customer_name)VALUES ('customer3');
INSERT INTO customer (customer_name)VALUES ('customer4');
INSERT INTO customer (customer_name)VALUES ('customer5');
INSERT INTO customer (customer_name)VALUES ('customer6');
INSERT INTO customer (customer_name)VALUES ('customer7');
INSERT INTO customer (customer_name)VALUES ('customer8');
INSERT INTO customer (customer_name)VALUES ('customer9');
INSERT INTO customer (customer_name)VALUES ('customer10');

-------

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,expire_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('LO','DO','2019-12-17','2019-12-17',9000,5,'1','1',1,1);

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,expire_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('MO','DO','2019-12-16','2019-12-16',5000,6,'1','1',2,1);

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,expire_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('LO','GO','2019-12-13','2019-12-17',5000,7,'1','1',1,1);

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,expire_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('LO','GO','2019-12-12','2019-12-10',5000,7,'1','1',2,1);

----------------------
INSERT INTO customer_order
(order_type,day_order_type,from_order_date,expire_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('LO','GO','2019-12-11','2019-12-06',5000,7,'1','1',1,1);

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,expire_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('LO','GO','2019-12-10','2019-12-09',5000,7,'1','1',1,1);

INSERT INTO customer_order
(order_type,day_order_type,from_order_date,expire_date,order_price,order_quantity,status,order_status,customer_id,product_id)
VALUES ('LO','GO','2019-12-09','2019-09-05',5000,7,'1','1',1,1);




-----
select * from customer_order;

SELECT count(from_order_date) as day_count,order_price,order_quantity,(order_price*order_quantity) as order_amount
FROM customer_order
WHERE  from_order_date = '2019-12-17';


SELECT count(from_order_date) as day_count,order_price,order_quantity,(order_price*order_quantity) as order_amount
FROM customer_order
WHERE  from_order_date <= '2019-12-16' and from_order_date >= '2019-12-12';


SELECT DISTINCT(customer_id)
FROM customer_order
WHERE  from_order_date <= '2019-12-16' and from_order_date >= '2019-12-12';

SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date <= '2019-12-16' AND from_order_date >='2019-12-12'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='2'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'



SELECT DISTINCT(customer_id) FROM customer_order WHERE from_order_date <= '2019-12-16' AND from_order_date >='2019-09-19'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date = '2019-12-16' AND from_order_date='2019-09-19'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='2'AND from_order_date = '2019-12-16' AND from_order_date='2019-09-19'



SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-17' AND from_order_date>='2019-12-12'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='2'AND from_order_date <= '2019-12-17' AND from_order_date>='2019-12-12'


SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount,count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1' AND from_order_date = '2019-12-17'


SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-17' AND from_order_date>='2019-12-12'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-17' AND from_order_date>='2019-12-12'
					
select * from customer_order;


SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'
	

SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount,count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1' AND from_order_date = '2019-12-17'
SELECT customer.customer_id,customer.customer_name,SUM(order_price),SUM(order_quantity),order_quantity*order_price AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'



SELECT customer.customer_id,customer.customer_name,SUM(order_price),SUM(order_quantity),SUM(order_quantity)*SUM(order_price) AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'

select * from customer_order;


SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount,count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1' AND from_order_date = '2019-12-17'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,SUM(order_quantity*order_price) AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'
SELECT customer.customer_id,customer.customer_name,SUM(order_price),SUM(order_quantity),SUM(order_quantity)*SUM(order_price) AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='2'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'


SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount,count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1' AND from_order_date = '2019-12-17'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,SUM(order_quantity*order_price) AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,SUM(order_quantity*order_price) AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND customer.customer_id='2'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'


SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount,count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND order_status='1' AND customer.customer_id='1' AND from_order_date = '2019-12-17'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,order_quantity*order_price AS order_amount,count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND order_status='1' AND customer.customer_id='2' AND from_order_date = '2019-12-17'


SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,SUM(order_quantity*order_price) AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND order_status='1' AND customer.customer_id='1'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'
SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,SUM(order_quantity*order_price) AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND order_status='1' AND customer.customer_id='2'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'


select * from customer_order;

SELECT customer.customer_id,customer.customer_name,order_price,order_quantity,SUM(order_quantity*order_price) AS order_amount, count(from_order_date) as day_count FROM customer_order inner join customer on customer_order.customer_id=customer.customer_id WHERE status='1' AND order_status='1' AND customer.customer_id='2'AND from_order_date <= '2019-12-16' AND from_order_date>='2019-12-12'