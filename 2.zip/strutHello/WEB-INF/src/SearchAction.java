

import java.util.ArrayList;

import java.util.Date;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import model.Customer_Order;

import com.opensymphony.xwork2.ActionSupport;

import dbo.DBOperation;
public class SearchAction extends ActionSupport{
	

private Date today,from_date,to_date;

ArrayList<Customer_Order> s_list;
ArrayList<Customer_Order> search_list;
HttpServletRequest request=ServletActionContext.getRequest();
HttpSession session = request.getSession();



   public ArrayList<Customer_Order> getS_list() {
	return s_list;
}
public void setS_list(ArrayList<Customer_Order> s_list) {
	this.s_list = s_list;
}
public Date getToday() {
	return today;
}
public void setToday(Date today) {
	this.today = today;
}
public Date getFrom_date() {
	return from_date;
}
public void setFrom_date(Date from_date) {
	this.from_date = from_date;
}
public Date getTo_date() {
	return to_date;
}
public void setTo_date(Date to_date) {
	this.to_date = to_date;
}
public String execute() throws Exception {
	
	  Date date=new Date();
	  System.out.println(date.getDay()+"DAY");
	
       DBOperation  dbo=new DBOperation();      
       ArrayList<Customer_Order> s_list =dbo.search(today, from_date, to_date);
           
    
		 if(s_list==null){
			 return "error";
		 }else{
			  for (Customer_Order cust : s_list) {
		    	  
		    	   System.out.println(cust.getCustomer_id()+" "+cust.getCustomer_name()+" "+cust.getToday_order_amount()+" "+cust.getToday_order_amount()+" "+cust.getPrevious_avg_order_amount());         
		      }
		      
				 session.setAttribute("search_list", s_list);
				 ArrayList<Customer_Order> search_list= (ArrayList<Customer_Order>)session.getAttribute("search_list");
    	  return "success";  
		 }
      }


}
