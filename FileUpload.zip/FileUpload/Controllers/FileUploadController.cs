﻿using System;
using System.Web;
using System.IO;
using System.Web.Mvc;
using Microsoft.AspNetCore.Mvc;

namespace FileUpload.Controllers
{
    public class FileUploadController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(HttpPostedFileBase file)
        {

            try
            {

                if (file.ContentLength > 0)
                {
                    string filename = Path.GetFileName(file.FileName);
                    string filepath = Path.Combine(System.Web.HttpContext.Current.Server.MapPath("~/FileUpload"),filename);

                    Console.WriteLine(filepath+"fffffffffffffffff");
                    file.SaveAs(filepath);
                }

                ViewBag.Message="Uploaded file successfully saved in a folder";

                return View();
            }
            catch
            {
                ViewBag.Message = "Uploaded file not saved in a folder";
                return View();

            }
           
        }
    }
}